<template>
    <section class="bg-white flex justify-center">
        <div
            class="flex flex-col py-8  sm:justify-center"
        >
            <div class="flex flex-wrap justify-center xl:justify-between">
                <div class="flex flex-col">
                    <h1
                        class="max-w-4xl xl:max-w-3xl mb-6 sm:text-5xl text-4xl font-extrabold tracking-tight leading-none "
                    >
                        Большой выбор стартеров, генераторов и других автозапчастей
                    </h1>
                    <p
                        class="max-w-2xl mb-6 font-normal text-gray-500 lg:mb-8  text-2xl dark:text-gray-400"
                    >
                        Узнайте больше о наших запчастях
                    </p>
                </div>
                <img src="/starters.jpg" class="sm:w-[350px] sm:justify-between mb-6" alt="#"/>
            </div>
            <div class="flex flex-wrap items-center justify-center xl:justify-start">
                <a
                    href="/catalog/starters"
                    class="mt-2 sm:mt-0 inline-flex items-center justify-center px-16 py-6 mr-3 text-xl font-medium text-center text-white rounded-lg bg-green-700 hover:bg-green-900 "
                >
                    Стартеры
                    <svg
                        class="w-5 h-5 ml-2 -mr-1"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg"
                    >
                        <path
                            fill-rule="evenodd"
                            d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                            clip-rule="evenodd"
                        ></path>
                    </svg>
                </a>
                <a
                    href="/catalog/generators"
                    class="mt-2 sm:mt-0 inline-flex cursor-pointer items-center justify-center px-16 py-6 text-xl font-medium text-center text-gray-900 border border-gray-300 rounded-lg hover:bg-gray-100"
                >
                    Генераторы
                    <svg
                        class="w-5 h-5 ml-2 -mr-1"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg"
                    >
                        <path
                            fill-rule="evenodd"
                            d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                            clip-rule="evenodd"
                        ></path>
                    </svg>
                </a>
            </div>
        </div>
    </section>
</template>



