<template>
    <div class="w-full md:w-1/2">
        <form class="flex items-center">
            <label for="simple-search" class="sr-only">Search</label>
            <div class="relative w-full">
                <div class="absolute inset-y-0 left-0 flex items-center pl-3">
                    <svg
                        aria-hidden="true"
                        class="w-5 h-5 text-gray-500 "
                        fill="currentColor"
                        viewbox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg"
                    >
                        <path
                            fill-rule="evenodd"
                            d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                            clip-rule="evenodd"
                        />
                    </svg>
                </div>
                <input
                    type="text"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 p-2 focus:ring-primary-500 "
                    :placeholder="`${placeholder}`"
                    required
                    @input="getSearchingDetails"
                    v-model="searchQuery"
                />
            </div>
        </form>
    </div>
</template>

<script setup>
import axios from "axios";
import debounce from "lodash.debounce";
import {ref} from "vue";

const props = defineProps({
    placeholder: {
        type: String,
        default: "Search",
    },
    link: {
        type: String,
        default: "#",
    },
})

const emit = defineEmits(['setData']);

let searchQuery = ref("");

const getSearchingDetails = debounce(() => {
    axios
        .get(`${props.link}=${searchQuery.value}`)
        .then((res) => {
            console.log(res.data);
            emit("setData", res.data);
        })
        .catch((err) => console.log(err));
}, 1500);

</script>
