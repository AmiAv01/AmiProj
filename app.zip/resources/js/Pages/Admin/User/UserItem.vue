<template>
    <tr class="border-b ">
        <th
            scope="row"
            class="px-4 py-3 font-medium text-gray-900 whitespace-nowrap "
        >
            <a :href="`/admin/resource/users/${user.id}`">
                {{ user.id }}
            </a>
        </th>
        <td class="px-4 py-3">{{ user.name }}</td>
        <td class="px-4 py-3">{{ user.email }}</td>
        <td class="px-4 py-3">
            {{ (user.isAdmin === 1) ? "Да" : "Нет" }}
        </td>

        <td class="px-4 py-3 flex items-center justify-end">
            <button
                :id="`${user.id}-button`"
                :data-dropdown-toggle="`${user.id}`"
                class="inline-flex items-center p-0.5 text-sm font-medium text-center text-gray-500 hover:text-gray-800 rounded-lg focus:outline-none "
                type="button"
            >
                <svg
                    class="w-5 h-5"
                    aria-hidden="true"
                    fill="currentColor"
                    viewbox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path
                        d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM16 12a2 2 0 100-4 2 2 0 000 4z"
                    />
                </svg>
            </button>
            <div
                :id="`${user.id}`"
                class="hidden z-10 w-44 bg-white rounded divide-y divide-gray-100 shadow "
            >
                <div class="py-1">
                    <button
                        @click="deleteUser(user.id)"
                        class="flex w-full py-2 px-4 text-sm text-gray-700 hover:bg-gray-100 "
                    >
                        Удалить
                    </button>
                </div>
            </div>
            <button @click="approveUser(user.id)" v-if="!user.approved" class="`flex items-center text-white bg-green-700  hover:bg-green-800  font-medium rounded-lg  text-center p-2 ml-2`">Подтвердить</button>
            <MenuButton/>
        </td>
    </tr>
</template>

<script setup>
import MenuButton from "@/Components/MenuButton.vue";

const props = defineProps({
    user: {
        type: Object,
        default: null,
    }});

let isShow = false;

function showModal() {
    this.isShow = true;
}

function deleteUser(id){
    axios.delete(`/admin/resource/users/${id}`)
        .then(res => console.log(res.data))
        .catch(err => console.log(err))
}

function approveUser(id){
    axios.put(`/admin/resource/approve/${id}`)
        .then(res => {
            console.log(res.data);
            window.location.reload();
        })
        .catch(err => console.log(err))
}

</script>
