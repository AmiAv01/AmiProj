<?php

namespace App\Services\Cart;

use App\Exceptions\CartOperationException;
use App\Models\Cart;
use App\Models\CartItem;
use Illuminate\Support\Facades\Log;

final class CartService
{
    public function getOrCreateUserCart(int $userId): Cart
    {
        try {
            return Cart::firstOrCreate(['user_id' => $userId]);
        } catch (\Exception $e) {
            Log::error("Failed to get or create cart for user {$userId}", ['error' => $e]);
            throw new CartOperationException('Failed to get or create cart: '.$e->getMessage());
        }
    }

    public function getCartItems(Cart $cart): array
    {
        try {
            return $cart->items()->with('detail')->get()
                ->map(function ($item) {
                    if (! $item instanceof CartItem) {
                        return [];
                    }

                    $detail = $item->detail()->first();

                    return array_merge($item->toArray(), $detail ? $detail->toArray() : []);
                })->toArray();
        } catch (\Exception $e) {
            Log::error("Failed to get cart items for cart {$cart->id}", ['error' => $e]);
            throw new CartOperationException('Failed to get cart items: '.$e->getMessage());
        }
    }

    public function getCartItemsByUserId(int $userId): array
    {
        $cart = $this->getOrCreateUserCart($userId);

        return $this->getCartItems($cart);
    }

    public function getCartQuantity(Cart $cart)
    {
        return $cart->items()->sum('quantity');
    }

    public function clearCart(Cart $cart): void
    {
        $cart->items()->delete();
    }
}
